# JVLinkToSQLite
JVLinkToSQLite は、JRA-VAN データラボが提供する競馬データを SQLite データベースに変換するツールです。  
使い方については、[マニュアル](https://github.com/urasandesu/JVLinkToSQLite/wiki)をご参照ください。

